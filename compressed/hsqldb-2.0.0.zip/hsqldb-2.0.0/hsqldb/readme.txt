Readme File
$Date: 2010-06-06 20:59:13 -0400 (Sun, 06 Jun 2010) $
This package contains HyperSQL v. 2.0.0

HyperSQL is a relational database engine and a set of tools written in Java.
HyperSQL is also known as HSQLDB.

The file "index.html" explains the contents of this distribution and has
links to documentation and support resources.
